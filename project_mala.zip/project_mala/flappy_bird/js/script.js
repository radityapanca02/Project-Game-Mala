const firebaseConfig = {
    apiKey: "AIzaSyA5Q6d8fuqUa7pGAj4fX_3q_DUI9QATsg4",
    authDomain: "flappybirds-85796.firebaseapp.com",
    projectId: "flappybirds-85796",
    storageBucket: "flappybirds-85796.firebasestorage.app",
    messagingSenderId: "736903068",
    appId: "1:736903068:web:635a84822a2b9de89cd259",
    measurementId: "G-GJHTCHZDPK",
};

// Inisialisasi Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();

let highScore = 0;
let currentScore = 0;
let currentUser = localStorage.getItem("currentUser") || null;
let gameOver = false;
// Cek status login saat halaman dimuat
window.onload = () => {
    if (currentUser) {
        // document.getElementById("logoutBtn").style.display = "block";
        // console.log("Sedang login di", currentUser);
    }
};

// Fungsi untuk menyimpan skor ke leaderboard
function saveScore(username, score) {
    if (!username || !score) {
        // console.error("Username atau score tidak valid:", username, score);
        return;
    }
    console.log(currentScore)
    
    const leaderboardRef = database.ref("Leaderboard/" + username);
    leaderboardRef.once("value").then((snapshot) => {
        if (!snapshot.exists() || snapshot.val() < score) {
            leaderboardRef.set(score).then(() => {
                // console.log("Skor berhasil disimpan:", username, score);
            }).catch((error) => {
                // console.error("Gagal menyimpan skor:", error);
            });
        } else {
            // console.log("Skor tidak lebih tinggi, tidak disimpan:", username, score);
        }
    }).catch((error) => {
        // console.error("Gagal membaca data dari Firebase:", error);
    });
}

// Fungsi untuk menampilkan leaderboard
function showLeaderboard() {
    const leaderboardModal = new bootstrap.Modal(
        document.getElementById("leaderboardModal")
    );
    leaderboardModal.show();

    const leaderboardRef = database
        .ref("Leaderboard")
        .orderByValue()
        .limitToLast(10);
    leaderboardRef.on("value", (snapshot) => {
        const leaderboardList = document.getElementById("leaderboardList");
        leaderboardList.innerHTML = "";
        const scores = [];
        snapshot.forEach((childSnapshot) => {
            const username = childSnapshot.key;
            const score = childSnapshot.val();
            scores.push({ username, score });
        });

        // Urutkan dari skor tertinggi ke terendah
        scores.sort((a, b) => b.score - a.score);

        // Tampilkan di leaderboard
        scores.forEach((entry, index) => {
            const li = document.createElement("li");
            li.className = `leaderboard-item ${entry.username === currentUser ? "me" : ""
                }`;
            li.innerHTML = `
                <span class="rank">${index + 1}</span>
                <span class="icon">
                    ${index === 0
                    ? '<i class="fas fa-crown crown"></i>'
                    : index === 1
                        ? '<i class="fas fa-medal silver"></i>'
                        : index === 2
                            ? '<i class="fas fa-medal bronze"></i>'
                            : ""
                }
                </span>
                <span class="username">${entry.username === currentUser ? "Saya" : entry.username
                }</span>
                <span class="score">${entry.score}</span>
            `;
            leaderboardList.appendChild(li);
        });
    });
}

// Fungsi untuk menampilkan modal Login/Register
function showAuthModal() {
    const authModal = new bootstrap.Modal(document.getElementById("authModal"));
    authModal.show();
}

// Fungsi untuk menampilkan form Register
function showRegisterForm() {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("registerForm").style.display = "block";
    document.getElementById("authModalLabel").textContent = "Register";
}

// Fungsi untuk menampilkan form Login
function showLoginForm() {
    document.getElementById("registerForm").style.display = "none";
    document.getElementById("loginForm").style.display = "block";
    document.getElementById("authModalLabel").textContent = "Login";
}

// Fungsi untuk Register
function register() {
    const username = document.getElementById("registerUsername").value;
    const password = document.getElementById("registerPassword").value;

    if (!username || !password) {
        document.getElementById("registerError").textContent =
            "Username/Password tidak boleh kosong!";
        return;
    }

    const userRef = database.ref("User_Auth/" + username);
    userRef.once("value").then((snapshot) => {
        if (snapshot.exists()) {
            document.getElementById("registerError").textContent =
                "Username sudah digunakan!";
        } else {
            userRef.set({ password: password }).then(() => {
                alertSuccess("Register Berhasil!");
                const authModal = bootstrap.Modal.getInstance(
                    document.getElementById("authModal")
                );
                authModal.hide();
                showLoginForm();
            });
        }
    });
}

// Fungsi untuk Login
function login() {
    const username = document.getElementById("loginUsername").value;
    const password = document.getElementById("loginPassword").value;

    if (!username || !password) {
        document.getElementById("loginError").textContent =
            "Username/Password tidak boleh kosong!";
        return;
    }

    const userRef = database.ref("User_Auth/" + username);
    userRef.once("value").then((snapshot) => {
        if (!snapshot.exists()) {
            document.getElementById("loginError").textContent = "Username salah!";
        } else if (snapshot.val().password !== password) {
            document.getElementById("loginError").textContent = "Password salah!";
        } else {
            alertSuccess("Login Berhasil!");
            const authModal = bootstrap.Modal.getInstance(
                document.getElementById("authModal")
            );
            authModal.hide();
            currentUser = username;
            localStorage.setItem("currentUser", username); // Simpan status login
            document.getElementById("logoutBtn").style.display = "block";
        }
    });
}

// Fungsi untuk Logout
function logout() {
    currentUser = null;
    localStorage.removeItem("currentUser"); // Hapus status login
    document.getElementById("logoutBtn").style.display = "none";
    alertSuccess("Logout Berhasil!");
    goHome();
}

// Fungsi untuk Kembali Ke GP
function home() {
    currentUser = null;
    localStorage.removeItem("currentUser");
    document.getElementById("homeBtn")
    alertSuccess("Back To Home!");
}

// Fungsi untuk menampilkan alert sukses
function alertSuccess(message) {
    const alert = document.createElement("div");
    alert.className = "alert alert-success";
    alert.innerHTML = `<i class="fas fa-check"></i> ${message}`;
    document.body.appendChild(alert);
    setTimeout(() => alert.remove(), 3000);
}

// Fungsi untuk memulai game
function startGame() {
    document.getElementById("board").style.display = "block";
    document.querySelector(".game-container").style.display = "none";

    // Tampilkan teks "Start Game!"
    const countdownElement = document.getElementById("countdown");
    countdownElement.textContent = "Start Game!";
    countdownElement.style.display = "block";

    // Tunggu input dari pemain (spasi atau tap)
    document.addEventListener("keydown", handleStartInput);
    document.addEventListener("touchstart", handleStartInput);
}

// Fungsi untuk handle input start game
function handleStartInput(e) {
    if (e.code === "Space" || e.type === "touchstart") {
        // Sembunyikan teks "Start Game!"
        const countdownElement = document.getElementById("countdown");
        countdownElement.style.display = "none";

        // Hapus event listener setelah input diterima
        document.removeEventListener("keydown", handleStartInput);
        document.removeEventListener("touchstart", handleStartInput);

        // Mulai game
        initializeGame();
    }
}

// Fungsi untuk kembali ke home
function goHome() {
    const gameOverModal = bootstrap.Modal.getInstance(
        document.getElementById("gameOverModal")
    );
    if (gameOverModal) gameOverModal.hide();
    document.getElementById("board").style.display = "none";
    document.querySelector(".game-container").style.display = "block";
    gameOver = true; // Menghentikan game loop
}

// Fungsi untuk restart game dengan countdown
function restartGame() {
    const gameOverModal = bootstrap.Modal.getInstance(
        document.getElementById("gameOverModal")
    );
    if (gameOverModal) gameOverModal.hide();
    gameOver = false; // Reset gameOver
    startGame();
}

// Fungsi untuk menampilkan modal Game Over
function showGameOverModal() {
    const gameOverModal = new bootstrap.Modal(
        document.getElementById("gameOverModal")
    );
    document.getElementById("highScore").textContent = currentScore;
    gameOverModal.show();

    if (gameOverModal.show() || gameOver == true) {
        document.addEventListener("keydown", (e) => {
            if (["Space", "ArrowUp", "KeyX"].includes(e.code)) {
                gameOverModal.hide();
            }
        });
    }
    if (currentUser) {
        // console.log("Menyimpan skor untuk:", currentUser, currentScore);
        saveScore(currentUser, currentScore); // Simpan skor ke Firebase
    } else {
        // console.error("Tidak ada pengguna yang login, skor tidak disimpan.");
    }
}

// Fungsi untuk handle tombol Play
function handlePlay() {
    if (currentUser) {
        startGame();
    } else {
        showAuthModal();
    }
}

// Fungsi untuk memutar suara
function playSound(soundId) {
    const sound = document.getElementById(soundId);
    sound.currentTime = 0; // Reset waktu audio ke awal
    sound.play();
}

// Inisialisasi game
function initializeGame() {
    const boardWidth = window.innerWidth;
    const boardHeight = window.innerHeight;
    const birdWidth = 34;
    const birdHeight = 24;
    const pipeWidth = 64;
    const pipeHeight = 512;
    const gravity = 0.4;
    const velocityX = -2;
    const initialVelocityY = -6;
    const openingSpace = boardHeight / 4;

    let board, context;
    let birdImg, topPipeImg, bottomPipeImg;
    let velocityY = 0;
    gameOver = false;
    currentScore = 0;

    const bird = {
        x: boardWidth / 8,
        y: boardHeight / 2,
        width: birdWidth,
        height: birdHeight,
    };

    const pipeArray = [];

    board = document.getElementById("board");
    board.height = boardHeight;
    board.width = boardWidth;
    context = board.getContext("2d");

    birdImg = new Image();
    birdImg.src = "./assets/flappybird.png";
    birdImg.onload = () =>
        context.drawImage(birdImg, bird.x, bird.y, bird.width, bird.height);

    topPipeImg = new Image();
    topPipeImg.src = "./assets/toppipe.png";

    bottomPipeImg = new Image();
    bottomPipeImg.src = "./assets/bottompipe.png";

    function update() {
        if (gameOver) {
            return;
        }
        requestAnimationFrame(update);
        context.clearRect(0, 0, board.width, board.height);

        velocityY += gravity;
        bird.y = Math.max(bird.y + velocityY, 0);
        context.drawImage(birdImg, bird.x, bird.y, bird.width, bird.height);

        if (bird.y > board.height) {
            gameOver = true;
            playSound("hitSound"); // Putar suara nabrak
            showGameOverModal();
        }

        pipeArray.forEach((pipe) => {
            pipe.x += velocityX;
            context.drawImage(pipe.img, pipe.x, pipe.y, pipe.width, pipe.height);

            if (!pipe.passed && bird.x > pipe.x + pipe.width) {
                currentScore += 0.5;
                pipe.passed = true;
                playSound("pointSound"); // Putar suara dapat poin
            }

            if (detectCollision(bird, pipe)) {
                gameOver = true;
                showGameOverModal();
            }
        });

        pipeArray.filter((pipe) => pipe.x >= -pipeWidth);

        context.fillStyle = "white";
        context.font = "45px sans-serif";
        context.fillText(currentScore, 5, 45);

        if (gameOver) context.fillText("GAME OVER", 5, 90);
    }

    function placePipes() {
        if (gameOver) return;

        const randomPipeY = -pipeHeight / 4 - Math.random() * (pipeHeight / 2);

        const topPipe = {
            img: topPipeImg,
            x: boardWidth, // Mulai dari ujung kanan layar
            y: randomPipeY,
            width: pipeWidth,
            height: pipeHeight,
            passed: false,
        };
        pipeArray.push(topPipe);

        const bottomPipe = {
            img: bottomPipeImg,
            x: boardWidth, // Mulai dari ujung kanan layar
            y: randomPipeY + pipeHeight + openingSpace,
            width: pipeWidth,
            height: pipeHeight,
            passed: false,
        };
        pipeArray.push(bottomPipe);
    }

    function moveBird() {
        velocityY = initialVelocityY;
        playSound("jumpSound"); // Putar suara loncat

        if (gameOver) {
            restartGame();
        }
    }

    function detectCollision(a, b) {
        if (
            a.x < b.x + b.width &&
            a.x + a.width > b.x &&
            a.y < b.y + b.height &&
            a.y + a.height > b.y
        ) {
            gameOver = true;
            playSound("hitSound"); // Putar suara nabrak
            if (gameOver) {
                document.addEventListener("keydown", function (event) {
                    if (event.code === "Space") {
                        event.preventDefault();
                    }
                });
            }
            showGameOverModal();
            return true;
        }
        return false;
    }

    // Event listener untuk keyboard (PC)
    document.addEventListener("keydown", (e) => {
        if (["Space", "ArrowUp", "KeyX"].includes(e.code)) {
            moveBird();
        }
    });

    // Event listener untuk touch (Android)
    document.addEventListener("touchstart", () => {
        moveBird();
    });

    setInterval(placePipes, 1500);
    requestAnimationFrame(update);
}

// disable Dev-Tools
// source : https://stackoverflow.com/questions/28690564/is-it-possible-to-remove-inspect-element
// document.addEventListener("keydown", function (event) {
//     if (
//         event.key === "F12" ||
//         (event.ctrlKey && event.shiftKey && event.key === "I") ||
//         (event.ctrlKey && event.shiftKey && event.key === "J") ||
//         (event.ctrlKey && event.key === "U")
//     ) {
//         event.preventDefault();
//     }
// });
// document.addEventListener("contextmenu", function (event) {
//     event.preventDefault();
// });
