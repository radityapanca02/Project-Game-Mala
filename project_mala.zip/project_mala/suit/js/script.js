let menang_kalah = {
  batu: {
    batu: "seri",
    gunting: "menang",
    kertas: "kalah",
  },
  gunting: {
    batu: "kalah",
    gunting: "seri",
    kertas: "menang",
  },
  kertas: {
    kertas: "seri",
    gunting: "kalah",
    batu: "menang",
  },
};

let playerWin = 0;
let playerLose = 0;
let playerDraw = 0;

let computerWin = 0;
let computerLose = 0;
let computerDraw = 0;

function user(data) {
  let hasil_user = data;
  let ran = ["batu", "gunting", "kertas"];
  let acak = Math.floor(Math.random() * 3);
  let hasil_komputer = ran[acak];

  document.getElementById(
    "hasil-user"
  ).innerHTML = `<i class="fas fa-hand-${getIcon(
    hasil_user
  )} fa-3x ${getIconClass(hasil_user)}"></i>`;
  document.getElementById(
    "hasil-komputer"
  ).innerHTML = `<i class="fas fa-hand-${getIcon(
    hasil_komputer
  )} fa-3x ${getIconClass(hasil_komputer)}"></i>`;

  // Pindahkan elemen ke bawah saat alert muncul
  document.querySelector(".fJudul").classList.add("move-down");
  document.querySelector(".display").classList.add("move-down");

  switch (menang_kalah[hasil_user][hasil_komputer]) {
    case "kalah":
      showAlert("alertKalah", 2000); // Durasi 2 detik
      playerLose++;
      computerWin++;
      break;
    case "menang":
      showAlert("alertMenang", 1500); // Durasi 1,5 detik
      playerWin++;
      computerLose++;
      break;
    default:
      showAlert("alertSeri", 1000); // Durasi 1 detik
      playerDraw++;
      computerDraw++;
      break;
  }

  updateCounter();
}

function getIcon(choice) {
  switch (choice) {
    case "batu":
      return "rock";
    case "gunting":
      return "scissors";
    case "kertas":
      return "paper";
  }
}

function getIconClass(choice) {
  switch (choice) {
    case "batu":
      return "icon-batu";
    case "gunting":
      return "icon-gunting";
    case "kertas":
      return "icon-kertas";
  }
}

function updateCounter() {
  // Update Player Counter
  document.getElementById("player-win").innerText = `W: ${playerWin}`;
  document.getElementById("player-lose").innerText = `L: ${playerLose}`;
  document.getElementById("player-draw").innerText = `D: ${playerDraw}`;

  // Update Computer Counter
  document.getElementById("computer-win").innerText = `W: ${computerWin}`;
  document.getElementById("computer-lose").innerText = `L: ${computerLose}`;
  document.getElementById("computer-draw").innerText = `D: ${computerDraw}`;
}

function showAlert(alertId, duration) {
  let alert = document.getElementById(alertId);
  alert.style.display = "block";
  alert.style.opacity = 1;

  setTimeout(() => {
    alert.style.animation = "fadeOut 0.5s ease forwards";
    setTimeout(() => {
      alert.style.display = "none";
      // Kembalikan elemen ke posisi semula
      document.querySelector(".fJudul").classList.remove("move-down");
      document.querySelector(".display").classList.remove("move-down");
    }, 500); // Durasi fade out
  }, duration); // Durasi alert
}

function startGame() {
  let playerName = document.getElementById("playerNameInput").value;
  if (playerName.trim() === "") {
    document.getElementById("playerNameInput").classList.add("is-invalid");
  } else {
    document.getElementById("player-name").innerText = playerName;
    let modal = bootstrap.Modal.getInstance(
      document.getElementById("nameModal")
    );
    modal.hide();
  }
}

window.onload = function () {
  let modal = new bootstrap.Modal(document.getElementById("nameModal"));
  modal.show();
};
